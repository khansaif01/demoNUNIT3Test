﻿using System;

namespace demo
{
    public class Class1
    {
    }
}
